MÔJ TEST – OPRAVENÁ CLOUDOVÁ VERZIA

Čo je opravené:
- tlačidlo „Zmeniť Supabase pripojenie“
- automatické odstránenie /rest/v1/ z Project URL
- kontrola správneho tvaru Project URL
- možnosť kedykoľvek zmeniť Project URL a Publishable key

Project URL má vyzerať:
https://xxxxx.supabase.co

Nikdy nevkladaj Secret key, service_role key ani databázové heslo.
